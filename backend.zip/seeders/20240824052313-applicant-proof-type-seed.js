'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.bulkInsert('applicant_proof_type', [
      {
        proof_type_name: "Aadhaar"
      },
      {
        proof_type_name: "Pan-Card"
      },
    ]);
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.bulkDelete('applicant_proof_type', {}, null)
  }
};
